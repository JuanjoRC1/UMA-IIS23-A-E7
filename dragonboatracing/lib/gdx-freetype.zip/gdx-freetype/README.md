# GDX FreeType
gdx-freetype is currently built with FreeType v2.11.1.  
FreeType is provided as a git submodule in the `extensions/gdx-freetype/jni/freetype` directory. 


## Details
Details and usage instructions can be found on the [wiki](https://libgdx.com/wiki/extensions/gdx-freetype).
