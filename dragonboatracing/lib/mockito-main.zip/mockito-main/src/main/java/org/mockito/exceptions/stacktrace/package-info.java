/*
 * Copyright (c) 2007 Mockito contributors
 * This program is made available under the terms of the MIT License.
 */

/**
 * Stack trace filtering / cleaning public APIs.
 */
package org.mockito.exceptions.stacktrace;
